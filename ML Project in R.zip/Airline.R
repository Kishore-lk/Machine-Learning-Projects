library(tidyverse)
library(ggplot2)
library(caret)
library(dplyr)
library(haven)
library(ISLR)
library(randomForest)
library(corrplot)
airline <- read.csv(file="D:\\Masters in DA\\DM&ML 1\\Project\\Airline_Passenger_satisfaction.csv", header=TRUE)
str(airline)
head(airline)
names(airline)
sapply(airline,function(x) sum(is.na(x))) #checking for null attributes
airline$X <- NULL #deletion of unwanted column
library(Amelia)
#Visual representation of missing data
missmap(airline, legend = TRUE, col = c("red", "blue"))
#removing the null rows
airline <- na.omit(airline)
sapply(airline,function(x) sum(is.na(x)))
corrplot(cor(airline[sapply(airline,is.numeric)])) #correlation
#conversion into categorical variable
airline <- airline %>% 
  mutate(satisfaction = as.factor(ifelse(satisfaction == "neutral or dissatisfied", yes = "0", no = "1")),
         customer_type = as.factor(ifelse(customer_type == "disloyal Customer", yes = "0",no = "1")))

summary(airline)
#passenger satisfaction count
ggplot(airline, aes(x=satisfaction))+ geom_bar(fill="orange")+ labs(x="Satisfaction levels", y="counts", title = "Passenger satisfaction counts")
#passenger satisfaction count by gender
ggplot(data =airline, aes(x = satisfaction, fill = Gender )) + geom_bar() + labs(x="Satisfaction levels", y="counts", title = "Passenger satisfaction based on gender")
#cross validation
prop.table(table(airline$satisfaction))
#splitting the train and test data
set.seed(222)
index <- sample(nrow(airline), nrow(airline) *0.8) 
airline_train <- airline[index, ] 
airline_test <- airline[-index, ] 

#model 1: logistic regression
model_logreg <-  glm(formula = satisfaction ~ ., 
                     data = airline_train,
                     family = binomial("logit"))
summary(model_logreg)

#confusion matrix for test data
#  Obtaining class prediction
log_prob1 <-  predict(model_logreg,
                     newdata = airline_test,
                     type = "response")

log_label1 <-  as.factor(ifelse(log_prob1 > 0.5,
                               yes = "1",
                               no = "0"))

head(log_label1)
class(log_label1)
cm_log1 <- confusionMatrix(data = log_label1,
                          reference = airline_test$satisfaction,
                          positive = "0")
cm_log1  #printing confusion matrix of logistic Regression

#Confusion matrix for training data
#  Obtaining class prediction
log_prob2 <-  predict(model_logreg,
                      newdata = airline_train,
                      type = "response")

log_label2 <-  as.factor(ifelse(log_prob2 > 0.5,
                                yes = "1",
                                no = "0"))

head(log_label2)
class(log_label2)
cm_log2 <- confusionMatrix(data = log_label2,
                          reference = airline_train$satisfaction,
                          positive = "0")
cm_log2  #printing confusion matrix of logistic Regression

#Random forest

sapply(airline_test,function(x) sum(is.na(x)))
#airline_test <- na.omit(airline_test)
gc() #garbage collection
memory.limit() #checking memory limit
rf_model <- randomForest(satisfaction ~ age  + flight_distance  + seat_comfort  + departure_arrival_time_convenient + food_and_drink  + gate_location  + inflight_wifi_service  +
                           inflight_entertainment + onboard_service + ease_of_online_booking + online_boarding + leg_room_service, data = airline_train)
airline_test$satisfaction <- as.factor(airline_test$satisfaction)
class(rf_model) #checking class
print(rf_model) #printing model

# Confusion matrix of train data
p1 <- predict(rf_model, airline_train) #Obtaining class prediction
confusionMatrix(p1, airline_train$ satisfaction)
# confusion matrix of test data
p2 <- predict(rf_model, airline_test) #Obtaining class prediction
confusionMatrix(p2, airline_test$ satisfaction)
gc()

