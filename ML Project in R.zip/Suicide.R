library(tidyverse)
library(ggplot2)
library(caret)
library(dplyr)
library(haven)
library(ISLR)
library(rpart)
library(performance)
library(e1071)
library(kernlab)
suicide <- read.csv(file="D:\\Masters in DA\\DM&ML 1\\Project\\master.csv", header=TRUE)
str(suicide)
head(suicide)
names(suicide)
# Cleaning the age data by removing year string
suicide <- suicide %>% 
  mutate(age = str_remove(age,'years'))
suicide <- suicide %>% 
  mutate(age = str_remove(age," "))
head(suicide)
#checking for null attributes
sapply(suicide,function(x) sum(is.na(x))) 
library(Amelia)
#Visual representation of missing data
missmap(suicide, legend = TRUE, col = c("red", "blue"))
suicide$HDI.for.year <- NULL #deletion of unwanted column
sapply(suicide,function(x) sum(is.na(x)))
corrplot(cor(suicide[sapply(suicide,is.numeric)])) #correlation
#line plot for average suicide deaths per year and total suicide deaths per year
year_summary <- suicide %>%
  group_by(year) %>%
  summarize(`Total Suicide Deaths` = sum(suicides_no),
            `Average Suicide Deaths` = mean(suicides_no))
ggplot(year_summary, aes(x = year, y = `Total Suicide Deaths`)) +
  geom_point() +
  geom_path() + 
  theme_minimal()
#suicide$suicide_no <- as.numeric(suicide$suicide_no)
#histogram to see the number of suicide deaths
hist(suicide$suicides.100k.pop, xlab = "NUMBER OF SUICIDE DEATHS", ylab = "COUNT")

#suicide count by gender
ggplot(suicide, aes(x = sex, y = `suicides.100k.pop`)) +
  geom_point() +
  geom_path() + 
  theme_minimal()
#Suicide rate per year based on gender 
bar <- ggplot(suicide, aes(year,suicides.100k.pop, fill = sex))
bar + stat_summary(fun.y = mean, geom = "bar",
                   position="dodge") + stat_summary(fun.data =
                                                      mean_cl_normal, geom = "errorbar", position =
                                                      position_dodge(width = 0.90), width = 0.2) + labs(x =
                                                                                                          "year", y = "suicide rate 100k population", fill = "Gender")
#Suicide rate per age based on gender 
bar1 <- ggplot(suicide, aes(age,suicides.100k.pop, fill = sex))
bar1 + stat_summary(fun.y = mean, geom = "bar",
                   position="dodge") + stat_summary(fun.data =
                                                      mean_cl_normal, geom = "errorbar", position =
                                                      position_dodge(width = 0.90), width = 0.2) + labs(x =
                                                                                                          "age", y = "suicide rate 100k population", fill = "Gender")
#splitting the train and test data
set.seed(222)
index <- sample(nrow(suicide), nrow(suicide) *0.8) 
suicide_train <- suicide[index, ] 
suicide_test <- suicide[-index, ]
lm_model <- lm(suicides.100k.pop ~ age + year + sex+ suicides_no + country + population, data=suicide_train)
summary(lm_model)
model_performance(lm_model)
class(lm_model)
p1 <- predict(lm_model, suicide_train[,1:6])
mse <-mean((suicide_train$suicides.100k.pop - p1)^2)
print(mse)
mse <-sqrt(mean((suicide_train$suicides.100k.pop - p1)^2))
print(mse)
cor(suicide_train$suicides.100k.pop, p1) ^ 2
gc()

#Decision tree
d_model <- rpart(suicides.100k.pop ~ ., data=suicide_train)
print(d_model)
summary(d_model)
p1 <- predict(d_model, suicide_train)
mse <-(mean((suicide_train$suicides.100k.pop - p1)^2))
print(mse)
rmse <-sqrt(mean((suicide_train$suicides.100k.pop - p1)^2))
print(rmse)
cor(suicide_train$suicides.100k.pop, p1) ^ 2

#SVM
svm_model <- svm(suicides.100k.pop ~ age + year + sex+ suicides_no + population, data=suicide_train)
print(svm_model)
summary(d_model)
p1 <- predict(svm_model, suicide_train)
mse <-(mean((suicide_train$suicides.100k.pop - p1)^2))
print(mse)
rmse <-sqrt(mean((suicide_train$suicides.100k.pop - p1)^2))
print(rmse)
cor(suicide_train$suicides.100k.pop, p1) ^ 2 #finding R2
