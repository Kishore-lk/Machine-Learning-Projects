library(tidyverse)
library(ggplot2)
library(caret)
library(dplyr)
library(haven)
library(ISLR)
library(class)
library(corrplot)
hotel <- read.csv(file="D:\\Masters in DA\\DM&ML 1\\Project\\Hotel_Booking_satisfaction.csv", header=TRUE)
str(hotel)
head(hotel)
names(hotel)
sapply(hotel,function(x) sum(is.na(x))) #checking for null attributes
library(Amelia)
#Visual representation of missing data
missmap(airline, legend = TRUE, col = c("red", "blue"))
#renaming column name using dplyr rename()
hotel <- hotel %>% 
  rename(
    type_of_travel = Type.of.Travel,
    type_of_booking = Type.Of.Booking
  )
corrplot(cor(hotel[sapply(hotel,is.numeric)])) #correlation
#conversion of variable
hotel <- hotel %>% 
  mutate(satisfaction = as.factor(ifelse(satisfaction == "satisfied", yes = "1", no = "0")))

summary(hotel)
#Customer satisfaction count
ggplot(hotel, aes(x=satisfaction))+ geom_bar(fill="orange")+ labs(x="Satisfaction levels", y="counts", title = "Customer satisfaction counts")
#Customer satisfaction count by gender
ggplot(data = hotel, aes(x = satisfaction, fill = Gender )) + geom_bar() + labs(x="Satisfaction levels", y="counts", title = "Customer satisfaction based on gender")
#cross validation
prop.table(table(hotel$satisfaction))
#splitting the train and test data
set.seed(222)
index <- sample(nrow(hotel), nrow(hotel) *0.8) 
hotel_train <- hotel[index, ] 
hotel_test <- hotel[-index, ] 

# predictor
hotel_train1 <- hotel_train %>% select(-c(satisfaction, Gender, purpose_of_travel, type_of_travel, type_of_booking))
hotel_test1 <- hotel_test %>% select(-c(satisfaction, Gender, purpose_of_travel, type_of_travel, type_of_booking))

# target
hotel_train2 <- hotel_train %>% select(satisfaction)
hotel_test2 <- hotel_test %>% select(satisfaction)

hotel_trains <- scale(x = hotel_train1)
hotel_tests <- scale(x = hotel_test1, 
                         center = attr(hotel_trains, "scaled:center"), 
                         scale = attr(hotel_trains, "scaled:scale"))
head(hotel_tests)

#Obtaining class prediction
round(sqrt(nrow(hotel_train)))
knn_label <- knn(train = hotel_trains,
                 test = hotel_tests,
                 cl = hotel_train2$satisfaction, 
                 k = 288)
head(knn_label)
class(knn_label)
cm_knn <- confusionMatrix(data = knn_label,
                          reference = hotel_test$satisfaction,
                          positive = "1")
cm_knn
